let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 BTH BOAT 〙 ═
╠➥  Made in javascript via NodeJs
╠➥ Rec: ARAKKAL BASI [LOVE ONLY]
╠➥ Script: ARAKKAL BASI
║
╠➥
╠➥ INSTAGRAM : https://instagram.com/bhasi_bth_?igshid=fi0ooi3fd9lf
╠➥ You tube : http://youtu.be/oPAdoD3rhkl
║
╠═〘 Thanks To 〙 ═
╠➥ DEVAN
╠➥ LOVE ONLY
╠➥ 
║
╠➥ [BOAT]
╠➥ MAKE GROUP ADMIN 
╠➥ TURN ON YOUR DATA
╠➥ CONTACT : wa.me//+918891903810
║
║>Request? wa.me//+918891903810
║
╠═〘 BHT BOAT 〙 ═
`.trim(), m)
}
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

